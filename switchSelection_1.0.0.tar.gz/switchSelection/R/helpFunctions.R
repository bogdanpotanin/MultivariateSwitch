# Merge all variables in several formulas
formula.merge <- function(..., type = "all")
{
  formulas <- list(...)
  if (is.list(formulas[[1]]))
  {
    formulas <- formulas[[1]]
  }
  f.y <- NULL
  f.x <- NULL
  for (i in 1:length(formulas))
  {
    f.x <- c(f.x, labels(terms(formulas[[i]])))
    f.y <- c(f.y, all.vars(formulas[[i]])[1])
  }
  
  if (type == "all")
  {
    f.c <- unique(c(f.x, f.y))
  }
  if (type %in% c("terms", "var-terms"))
  {
    f.c <- unique(f.x)
  }
  
  frm <- do.call(paste, c(as.list(f.c), sep = " + "))
  frm <- paste("~ ", frm)
  if(type == "var-terms")
  {
    frm <- paste(f.y[1], frm)
  }
  frm <- as.formula(frm)
  
  return(frm)
}
formula.merge(as.formula("y1 ~ x1 + x2"), 
              as.formula("y2 ~ x2 + x3"), 
              as.formula("y3 ~ y2 + x6"))

# Split formula by '|' symbol
formula.split <- function(f)
{
  f <- as.formula(f)
  fs <- paste(f[2], f[3], sep = '~')
  f <- strsplit(x = fs, split = "|", fixed = TRUE)
  
  f1y <- strsplit(x = f[[1]][1], split = "~", fixed = TRUE) 
  y <- f1y[[1]][1]
  f1 <- f1y[[1]][2]
  f2 <- f[[1]][2]
  
  f1 <- as.formula(paste(y, "~", f1))
  f2 <- as.formula(paste(y, "~", f2))
  
  f_out <- list(f1 = f1,
                f2 = f2)
  return(f_out)
}
formula.merge(formula.split("y ~ x1 + x2 | x2 + x3"), type = "var-terms")

# Bootstrap for least square
lm.boot <- function(model, iter = 1000)
{
  data <- model.frame(model)
  n <- nrow(data)
  model.boot <- vector(mode = "list", length = iter)
  coef.boot <- matrix(NA, nrow = iter, ncol = ncol(data))
  for (i in 1:iter)
  {
    ind.boot <- sample(1:n, size = n, replace = TRUE)
    data.boot <- data[ind.boot, ]
    model.boot[[i]] <- lm(data.boot[, 1] ~ ., data = data.boot[, -1])
    coef.boot[i, ] <- coef(model.boot[[i]])
  }
  coef.names <- names(data)
  coef.names[1] <- "(Intercept)"
  cov.boot <- cov(coef.boot)
  colnames(cov.boot) <- coef.names
  rownames(cov.boot) <- coef.names
  return(cov.boot)
}

# Cross-validation
loocv <- function(fit)
{
  h <- lm.influence(fit)$h
  loocv_value <- sqrt(mean((residuals(fit)/(1 - h)) ^ 2))
  
  return(loocv_value)
}

# Stars
starsVector <- function(p_value)
{
  n <- length(p_value)
  stars <- rep(NA, n)
  
  for (i in 1:n)
  {
    if (p_value[i] > 0.1)
    {
      stars[i] <- ""
      next
    }
    
    if ((p_value[i] <= 0.1) & (p_value[i] > 0.05))
    {
      stars[i] <- "*"
      next
    }
    
    if ((p_value[i] <= 0.05) & (p_value[i] > 0.01))
    {
      stars[i] <- "**"
      next
    }
    if (p_value[i] <= 0.01)
    {
      stars[i] <- "***"
      next
    }
  }
  
  return(stars)
}
