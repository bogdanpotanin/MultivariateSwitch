#' Multinomial probit model
#' @param formula an object of class "formula": a symbolic description 
#' of the model to be fitted.
#' @return This function returns the list containing the information on the
#' results of the genetic algorithm
mnprobit <- function(formula, data, 
                     start = NULL,
                     n_sim = 1000, 
                     opt_method = "optim",
                     n_cores = 1)
{   
  # Coerce formula to type 'formula'
  formula <- as.formula(formula)
  
  # Get dataframe according to the formula
  df <- model.frame(formula, data, na.action = na.omit)
  
  # Extract dependent variables and regressors
  z <- df[, 1]                                             # dependent variable
  W <- cbind(1, df[, -1])                                  # regressors
  
  # Get the number of coefficients (regressors)
  # for a single alternative
  n_coef <- ncol(W)
  
  # Get all the alternatives
  alt <- sort(unique(z))
  
  # Calculate the number of alternatives
  n_alt <- length(alt)
  
  # Estimate the number of observations
  n_obs <- length(z)
  
  # # Set base alternative to be the last one that is 
  # # standardized to zero
  # if (!is.null(alt_base))
  # {
  #   # Find the index of base alternative
  #   alt_base_ind <- which(alt == alt_base)
  #   
  #   # Check that user defined base alternative exists
  #   if (length(alt_base_ind) != 1)
  #   {
  #     stop(paste0("There is no alternative named ", alt_base, ". ",
  #                 "Please, provide correct value to alt_base argument"))
  #   }
  #     
  #   # Substitute the base alternative with the last one
  #   alt[alt_base_ind] <- alt[n_alt]
  #   
  #   # Set base alternative to be the last one
  #   alt[n_alt] <- alt_base
  # }
  
  # Get the number of the covariance matrix 
  # elements to be estimated
  n_sigma <- ((n_alt - 1) ^ 2 - (n_alt - 1)) / 2 + (n_alt - 2)
  
  # Get the number of regression coefficients
  n_coef_total <- n_coef * (n_alt - 1)
  
  # Calculate the total number of estimated parameters
  n_par <- n_coef_total + n_sigma
  
  # Get indexes of coefficients
  coef_ind <- 1:n_coef_total
  sigma_ind <- (n_coef_total + 1):n_par
  
  # Store the coefficients indexes for each alternative
  coef_ind_alt <- matrix(NA, nrow = n_coef, ncol = n_alt - 1)
  for (i in 1:(n_alt - 1)) 
  {
    coef_ind_alt[, i] <- ((i - 1) * n_coef + 1):(i * n_coef)
  }
  
  # Store the information into the list
  control_lnL <- list(n_par = n_par,
                      n_alt = n_alt,
                      n_obs = n_obs,
                      n_coef = n_coef,
                      n_coef_total = n_coef_total,
                      n_sigma = n_sigma,
                      coef_ind = coef_ind - 1,
                      sigma_ind = sigma_ind - 1,
                      coef_ind_alt = coef_ind_alt - 1)
  
  # Create a starting point for the numeric 
  # optimization routine
  if (is.null(start))
  {
    start <- rep(0, n_par)
    cumsum_i <- 0
    for (i in 2:(n_alt - 1))                               # starting values
    {                                                      # for variances
      cumsum_i <- cumsum_i + i                             # should be equal
      start[n_coef_total + cumsum_i] <- 1                  # to one
    }       
  }

  # Perform the optimization routine
  opt <- NULL
  opt <- optim(par = start,
               method = "BFGS",
               fn = lnL_mnprobit,
               gr = grad_mnprobit,
               control = list(maxit = 1000000,
                              fnscale = -1,
                              reltol = 1e-10),
               W = as.matrix(W), z = as.vector(z), 
               alt = alt, n_sim = n_sim,
               n_cores = n_cores,
               control_lnL = control_lnL)
  
  # Add genetic optimization if need
  if (opt_method == "gena")
  {
    opt <- gena::gena(fn = lnL_mnprobit,
                      gr = grad_mnprobit,
                      pop.initial = opt$par,
                      mutation.method = "percent", 
                      maxiter = 100, info = TRUE,
                      lower = -2 * abs(opt$par), 2 * abs(opt$par),
                      W = as.matrix(W), z = as.vector(z), 
                      alt = alt, n_sim = n_sim,
                      n_cores = n_cores,
                      control_lnL = control_lnL)
  }
  
  # Store parameters estimates
  par <- opt$par
  
  # Store the coefficients
  coef <- matrix(NA, nrow = n_coef, ncol = n_alt - 1)
  for (i in 1:(n_alt - 1))
  {
    coef[, i] <- opt$par[coef_ind_alt[, i]]
  }
  
  # Store the covariance matrix
  sigma <- matrix(NA, nrow = n_alt - 1, ncol = n_alt - 1)
  sigma[1, 1] = 1;
  if (n_alt > 2)
  {
    counter <- 1;
    sigma_vec <- par[sigma_ind]
    for (i in 1:(n_alt - 1))
    {
      for (j in 1:i)
      {
        if (!((i == 1) & (j == 1)))
        {
          sigma[i, j] <- sigma_vec[counter]
          sigma[j, i] <- sigma[i, j];
          counter <- counter + 1
        }
      }
    }
  }
  
  # Output list
  out <- list(par = par,
              coef = coef,
              sigma = sigma,
              logLik = opt$value,
              independent.variables = W,
              dependent.variable = z,
              control_lnL = control_lnL,
              formula = formula)
  class(out) <- "mnprobit"
  
  # return
  return(out)
}

#' Multinomial probit model
#' @param formula an object of class "formula": a symbolic description 
#' of the model to be fitted.
#' @return This function returns the list containing the information on the
#' results of the genetic algorithm
predict.mnprobit <- function(model, alt = 1, 
                             type = "prob", newdata = NULL,
                             alt_obs = "all",
                             n_sim = 5000, n_cores = 1)
{   
  # Store the data
  if (!is.null(newdata))
  {
    df <- model.frame(model$formula, data = newdata, na.action = na.omit)
    W <- cbind(1, df[, -1])
    z <- df[, 1]
    n_obs <- nrow(W)
  }
  else
  {
    W <- as.matrix(model$independent.variables)
    z <- as.vector(model$dependent.variable)
  }
  coef <- model$coef
  sigma <- model$sigma
  n_alt <- model$control_lnL$n_alt
  n_obs <- model$control_lnL$n_obs
  
  # # Slightly transform sigma_alt if need
  # if (exists("cor_bounds", where = control))
  # {
  #   sigma_cor <- cov2cor(sigma)
  #   for (i in 2:(n_alt - 1))
  #   {
  #     for (j in 1:(i - 1))
  #     {
  #       if (sigma[i, j] > control$cor_bounds[2])
  #       {
  #         sigma_cor[i, j] <- control$cor_bounds[2]
  #         sigma_cor[j, i] <- sigma_cor[i, j]
  #       }
  #       if (sigma_cor[i, j] < control$cor_bounds[1])
  #       {
  #         sigma_cor[i, j] <- control$cor_bounds[1]
  #         sigma_cor[j, i] <- sigma_cor[i, j]
  #       }
  #     }
  #   }
  #   sigma_sd <- diag(sqrt(diag(sigma)))
  #   sigma <- sigma_sd %*% sigma_cor %*% sigma_sd
  # }
  
  # Select appropriate observations
  if (alt_obs != "all")
  {
    if (alt_obs == "alt")
    {
      alt_obs <- alt
    }
    alt_ind = which(z %in% alt_obs)
    n_obs <- length(alt_ind)
    W <- W[alt_ind, ]
    z <- z[alt_ind]
  }

  # Calculate linear index
  li <- matrix(NA, nrow = n_obs, ncol = n_alt - 1)
  for (i in 1:(n_alt - 1))
  {
    li[, i] <- W %*% coef[, i]
  }

  # Return linear indexes if enough
  if (type == "li")
  {
    return(li[, alt])
  }
  
  # Create transformation matrix
  transform_mat <- matrix(0, nrow = n_alt, ncol = n_alt)
  diag(transform_mat) <- 1
  if (alt != n_alt)
  {
    transform_mat[, alt] <- -1
  }
  transform_mat <- transform_mat[-alt, , drop = FALSE]
  transform_mat <- transform_mat[, -n_alt, drop = FALSE]

  # Construct covariance matrix for alternative
  sigma_alt <- transform_mat %*% sigma %*% t(transform_mat)
  
  # Calculate the differences between linear indexes
  li_diff <- matrix(NA, n_obs, n_alt - 1);
  if (alt == n_alt)
  {
    li_diff <- -li;
  }
  else
  {
    li_diff[, n_alt - 1] <- li[, alt];
    li_diff[, -(n_alt - 1)] <- apply(li[, -alt, drop = FALSE], 2, 
                                     function(x)
                                     {
                                       return(li[, alt] - x)
                                     }
                                     ) 
    # counter <- 0
    # for (j in 1:(n_alt - 1))
    # {
    #   if (alt != j)
    #   {
    #     li_diff[, counter] = li[, alt] - li[, j]
    #     counter <- counter + 1
    #   }
    # }
  }

  # Calculate the probabilities
  lower_neg_inf <- matrix(-Inf, nrow = n_obs, ncol = n_alt - 1)
  prob = mnorm::pmnorm(lower = lower_neg_inf, upper = li_diff,
                       mean = rep(0, n_alt - 1), sigma = sigma_alt,
                       n_sim = 5000, n_cores = n_cores, 
                       is_validation = FALSE)$prob;
  
  if (type == "prob")
  {
    return(prob)
  }
  
  # Calculate lambdas
  lambda = mnorm::pmnorm(lower = lower_neg_inf, upper = li_diff,
                         mean = rep(0, n_alt - 1), sigma = sigma_alt,
                         grad_upper = TRUE,
                         log = TRUE, 
                         n_sim = 5000, n_cores = n_cores, 
                         is_validation = FALSE)$grad_upper

  # return the results
  if (type == "lambda")
  {
    return(lambda)
  }
  
  # If everything should be returned
  out <- list(li = li,
              li_diff = li_diff,
              prob = prob,
              lambda = lambda)
  
  return("No return value has been specified")
}