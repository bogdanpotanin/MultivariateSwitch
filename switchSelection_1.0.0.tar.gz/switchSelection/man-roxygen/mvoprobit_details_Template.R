#' @details Multivariate ordered probit model with heteroscedastic
#' random errors has the following form:
#' \deqn{z_{ji}^{*} = w_{ji}\gamma_{j} + \sigma_{ji}u_{ji}} 
#'  \deqn{z_{i}=(z_{1i},...,z_{Ji})^{T},\quad
#'        u_{i} = (u_{1i},u_{2i},...,u_{Ji})^{T},}
#' \deqn{\sigma_{ji} = \exp(w_{ji}^{*}\gamma_{j}^{*}), \quad 
#'       u_{i}\sim N\left(\begin{bmatrix}0\\ \vdots\\ 0\end{bmatrix}, 
#'                        \Sigma\right), i.i.d.,}
#' \deqn{\Sigma = \begin{bmatrix}
#'                1 & \rho_{12} & \rho_{13} & ... & \rho_{1J}\\
#'                \rho_{12} & 1 & \rho_{23} & ... & \rho_{2J}\\
#'                \rho_{13} & \rho_{23} & 1 & ... & \rho_{3J}\\
#'                \vdots & \vdots & \vdots & \ddots & \vdots\\
#'                \rho_{1J} & \rho_{2J} & \rho_{3J} & ... & 1\\
#'                \end{bmatrix},}
#' \deqn{z_{ji}=\begin{cases}
#'                    0\text{, if }z_{ji}^{*}\leq c_{j1}\\
#'                    1\text{, if }c_{j1}<z_{ji}^{*}\leq c_{j2}\\
#'                    2\text{, if }c_{j2}<z_{ji}^{*}\leq c_{j3}\\
#'                    \vdots\\
#'                    m_{j}\text{, if }z_{ji}^{*}>c_{jm_{j}}\\
#'                    \end{cases},}
#' \deqn{i\in\{1,2,...,n\},\quad j\in\{1,2,...,J\}.}
#' Where:
#' \itemize{
#' \item \eqn{n} - the number of observations. If there are no omitted 
#' observations then \eqn{n} equals to \code{nrow(data)}.
#' \item \eqn{J} - the number of equations i.e. \code{length(formula)}.
#' \item \eqn{z_{ji}^{*}} - unobservable (latent) value of the \code{j}-th
#' dependent variable.
#' \item \eqn{z_{ji}} - observable (ordered) value of the \code{j}-th
#' dependent variable. Note that \eqn{z_{ji}\in\{0,1,...,m_{j}\}}.
#' \item \eqn{c_{jk}} - \eqn{k}-th cut of the \code{j}-th dependent variable.
#' \item \eqn{w_{ji}} - regressors of the \eqn{j}-th mean equation 
#' which should be described in \code{formula[[j]]}.
#' \item \eqn{\gamma_{j}} - regression coefficients of the \eqn{j}-th 
#' mean equation.
#' \item \eqn{w_{ji}\gamma_{j}} - linear index of the \eqn{j}-th mean equation.
#' \item \eqn{u_{i}} - multivariate normal random vector which elements are
#'                     standard normal variates.
#' \item \eqn{\Sigma} - correlation matrix of \eqn{u_{i}} i.e. 
#' \eqn{\Sigma_{t_{1}t_{2}}=\rho_{\min(t_{1},t_{2}),\max(t_{1}t_{2})}=
#'      \text{corr}\left(u_{it_{1}}, u_{it_{1}}\right)}.
#' \item \eqn{\sigma_{ji}} - heteroscedastic standard deviation.
#' \item \eqn{\sigma_{ji}u_{ji}} - heteroscedastic random errors.
#' \item \eqn{w_{ji}^{*}} - regressors of the \eqn{j}-th variance equation 
#' which should be described in \code{formula[[j]]} after '|' symbol.
#' \item \eqn{\gamma_{j}^{*}} - regression coefficients of the \eqn{j}-th 
#' variance equation.
#' \item \eqn{w_{ji}^{*}\gamma_{j}^{*}} - linear index of the \eqn{j}-th 
#' variance equation.
#' }
#' Parameters of this model are estimated via maximum-likelihood method
#' using numeric optimization technic provided through \code{opt_type} 
#' argument. The type of covariance matrix estimator may be provided
#' through \code{cov_type} argument.
#' 
#' To account for (non-random) sample selection unobservable values of 
#' dependent variables
#' should be coded as -1 (instead of 0 or 1). For example if \eqn{z_{1}} is
#' binary variable for employment status (0 - unemployed, 1 - employed) and
#' \eqn{z_{2}} is ordered variable (ranging from 0 to 2) for job satisfaction
#' (0 - unsatisfied, 1- slightly unsatisfied, 2 - satisfied) 
#' then \eqn{z_{2}} is observable
#' only when \eqn{z_{1}} equals 1 since job satisfaction observable only for
#' working individuals. Consequently \eqn{z_{2}} should be equal 
#' to -1 (minus one) whenever \eqn{z_{1}} equals to 0. If variables are coded 
#' in this way then \code{groups} matrix will be created automatically. 
#' Otherwise user may provide manual structure of selection mechanism by 
#' mentioning all possible combinations of \eqn{z_{1}} and \eqn{z_{2}} values as 
#' a rows of \code{groups} matrix. In this particular example matrix
#' \code{groups} will have the following form (no need to provide it manually):
#' \deqn{\text{groups} =
#' \begin{bmatrix}
#' 1 & 2\\
#' 1 & 1\\
#' 1 & 0\\
#' 0 & -1                     
#'\end{bmatrix}}
#' Again, please, insure that all \eqn{z_{2}} equal to -1 for all 
#' \eqn{z_{1}} which equal to 0 in your \code{data}. Then matrix \code{groups}
#' will automatically have the aforementioned structure 
#' (accounting for non-random sample selection).
#' 
#' If some variables \eqn{z_{ji}} are missing i.e. take \code{NA} value then
#' contribution of other dependent variables (for the i-th observation) 
#' still may be included into the
#' likelihood function by manually substituting \code{NA} with -1 in your 
#' \code{data}. However insure that this particular (missing) \eqn{z_{ji}} is 
#' not a regressor for other dependent variable 
#' (that may happen in hierarchical systems).
#' 
#' Constant terms (intercepts) are excluded from the model for identification 
#' purposes. If \eqn{z_{ji}} is a binary variable then \eqn{-c_{j1}} may be 
#' interpreted as a constant term of the \eqn{j}-th equation. 
#' If all \eqn{z_{ji}} are binary variables then the model becomes
#' multivariate probit.
#' 
#' Currently \code{control} has no input arguments intended for the users. 
#' This argument is used for some internal purposes of the package.
#' 
#' Function \code{\link[mnorm]{pmnorm}} is used internally for calculation
#' of multivariate normal probabilities.
