#' @examples
#' # -------------------------------
#' # Example 1
#' # Ordered probit model
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' u <- rnorm(n = n, mean = 0, sd = 1)
#' 
#' # Coefficients
#' gamma <- c(-1, 2)
#' 
#' # Linear index
#' li <- gamma[1] * w1 + gamma[2] * w2
#' 
#' # Latent variable
#' z_star <- li + u
#' 
#' # Cuts
#' cuts <- c(-1, 0.5, 2)
#' 
#' # Observable ordered outcome
#' z <- rep(0, n)
#' z[(z_star > cuts[1]) & (z_star <= cuts[2])] <- 1
#' z[(z_star > cuts[2]) & (z_star <= cuts[3])] <- 2
#' z[z_star > cuts[3]] <- 3
#' table(z)
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, z = z)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Estimation
#' model <- mvoprobit(z ~ w1 + w2,
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients
#' cbind(true = gamma, estimate = model$coef[[1]])
#'   # cuts
#' cbind(true = cuts, estimate = model$cuts[[1]])   
#' 
#' # ---
#' # Step 3
#' # Estimation of probabilities and marginal effects
#' # ---
#' 
#' # Predict probability of dependent variable
#' # equals to 2 for every observation in a sample.
#' # P(z = 2)
#' prob <- predict(model, group = 2, type = "prob")
#' head(prob)
#' 
#' # Calculate mean marginal effect of w2 on P(z = 1)
#' mean(predict(model, group = 1, type = "prob", me = "w2"))
#' 
#' # Calculate probabilities and marginal effects
#' # for manually provided observations.
#'   # new data
#' newdata <- data.frame(z = c(1, 1), 
#'                       w1 = c(0.5, 0.2), 
#'                       w2 = c(-0.3, 0.8))
#'   # probability P(z = 2)
#' predict(model, group = 2, type = "prob", newdata = newdata)
#'   # linear index
#' predict(model, type = "li", newdata = newdata)  
#'   # marginal effect of w1 on P(Z = 2)
#' predict(model, group = 2, type = "prob", newdata = newdata, me = "w1")
#'   # marginal effect of w2 on the linear index
#' predict(model, group = 2, type = "li", newdata = newdata, me = "w2")
#'   # discrete marginal effect i.e. P(Z = 2 | w1 = 0.5) - P(Z = 2 | w1 = 0.2)
#' predict(model, group = 2, type = "prob", newdata = newdata, 
#'         me = "w2", eps = c(0.2, 0.5))
#'         
