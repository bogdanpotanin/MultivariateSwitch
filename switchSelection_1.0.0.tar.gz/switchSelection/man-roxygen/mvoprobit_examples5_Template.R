#' @examples
#' # -------------------------------
#' # Example 5
#' # Endogenous switching model
#' # with heteroscedastic
#' # ordered selection mechanism
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' rho_0 <- -0.8
#' rho_1 <- -0.7
#' var_y_0 <- 0.9
#' var_y_1 <- 1
#' sd_y_0 <- sqrt(var_y_0)
#' sd_y_1 <- sqrt(var_y_1)
#' cor_y_01 <- 0.7
#' cov_y_01 <- sd_y_0 * sd_y_1 * cor_y_01
#' cov_y_z_0 <- rho_0 * sd_y_0
#' cov_y_z_1 <- rho_1 * sd_y_1
#' sigma <- matrix(c(1,         cov_y_z_0, cov_y_z_1,
#'                   cov_y_z_0, var_y_0,   cov_y_01,
#'                   cov_y_z_1, cov_y_01,  var_y_1),
#'                 nrow = 3)
#' errors <- mnorm::rmnorm(n = n, mean = c(0, 0, 0), sigma = sigma)
#' u <- errors[, 1]
#' eps_0 <- errors[, 2]
#' eps_1 <- errors[, 3]
#' 
#' # Coefficients
#' gamma <- c(-1, 2)
#' gamma_het <- c(0.5, -1)
#' beta_0 <- c(1, -1, 1)
#' beta_1 <- c(2, -1.5, 0.5)
#' 
#' # Linear index of ordered equation
#'   # mean
#' li <- gamma[1] * w1 + gamma[2] * w2
#'   # variance
#' li_het <- gamma_het[1] * w2 + gamma_het[2] * w3
#' 
#' # Linear index of continuous equation
#'   # regime 0
#' li_y_0 <- beta_0[1] + beta_0[2] * w1 + beta_0[3] * w3
#'   # regime 1
#' li_y_1 <- beta_1[1] + beta_1[2] * w1 + beta_1[3] * w3
#' 
#' # Latent variable
#' z_star <- li + u * exp(li_het)
#' y_0_star <- li_y_0 + eps_0
#' y_1_star <- li_y_1 + eps_1
#' 
#' # Cuts
#' cuts <- c(-1, 0.5, 2)
#' 
#' # Observable ordered outcome
#' z <- rep(0, n)
#' z[(z_star > cuts[1]) & (z_star <= cuts[2])] <- 1
#' z[(z_star > cuts[2]) & (z_star <= cuts[3])] <- 2
#' z[z_star > cuts[3]] <- 3
#' table(z)
#' 
#' # Observable continuous outcome such
#' # that outcome 'y' is 
#' # in regime 1 when 'z == 1', 
#' # in regime 0 when 'z <= 1',
#' # unobservable when 'z == 0'
#' y <- rep(NA, n)
#' y[z == 0] <- Inf
#' y[z == 1] <- y_0_star[z == 1]
#' y[z > 1] <- y_1_star[z > 1]
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, w3 = w3, 
#'                    z = z, y = y)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Assign groups
#' groups <- matrix(0:3, ncol = 1)
#' groups2 <- matrix(c(-1, 0, 1, 1), ncol = 1)
#' 
#' # Estimation
#' model <- mvoprobit(list(z ~ w1 + w2 | w2 + w3),
#'                    list(y ~ w1 + w3),
#'                    groups = groups, groups2 = groups2,
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of ordered equation
#' cbind(true = gamma, estimate = model$coef[[1]])
#' cbind(true = gamma_het, estimate = model$coef_var[[1]])
#'   # cuts
#' cbind(true = cuts, estimate = model$cuts[[1]])   
#'   # regression coefficients of continuous equation
#' cbind(true = beta_0, estimate = model$coef2[[1]][1, ]) 
#' cbind(true = beta_1, estimate = model$coef2[[1]][2, ])
#'   # variances
#' cbind(true = c(var_y_0, var_y_1), estimate = model$var_y[[1]]) 
#'   # covariances
#' cbind(true = c(cov_y_z_0, cov_y_z_1), estimate = model$cov_y[[1]])
#' 
