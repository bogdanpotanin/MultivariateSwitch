#' @param formula list which i-th element is an object of class "formula"
#' describing the form of linear index for the i-th equation.
#' Mean and variance equations should be separated by '|' symbol.
#' @param data data frame containing the variables in the model.
#' @param groups matrix which (i, j)-th element is j-th ordered category
#' (value starting from 0) of i-th variable. Each row of this matrix describes 
#' observable (in data) combination of categories i.e. values of dependent 
#' variables. Special category '-1' means that variable in j-th column is 
#' unobservable when other dependent variables have particular values i.e. 
#' given in the same row. See 'Details' for additional information.
#' @param opt_type character representing optimization function to be used.
#' If \code{opt_type = "optim"} then \code{\link[stats]{optim}} will be used.
#' If \code{opt_type = "gena"} then \code{\link[gena]{gena}} will be applied 
#' i.e. genetic algorithm.
#' If \code{opt_type = "pso"} then \code{\link[gena]{pso}} will be used 
#' i.e. particle swarm optimization.
#' @param opt_args a list of input arguments for the optimization function
#' selected via \code{opt_type} argument.
#' @param start numeric vector of initial parameters' values. It will be used
#' as a starting point for optimization purposes.
#' @param cov_type character determining the type of covariance matrix to be
#' returned and used for summary. If \code{cov_type = "hessian"} then negative
#' inverse of Hessian matrix will be applied. If \code{cov_type = "gop"} then
#' inverse of Jacobian outer products will be used.
#' If \code{cov_type = "sandwich"} (default) then sandwich covariance matrix
#' estimator will be applied.
#' @param n_sim integer representing the number of GHK draws when there are
#' more then 3 equations. Otherwise alternative (much more efficient) algorithms
#' will be used to calculate multivariate normal probabilities.
#' @param n_cores positive integer representing the number of CPU cores used for 
#' parallel computing. If possible it is highly recommend to set it equal to
#' the number of available physical cores especially when the system of
#' ordered equations has 2 or 3 equations.
#' @param control a list of control parameters. See 'Details'.
