#' @examples
#' # -------------------------------
#' # Example 4
#' # Heckman model with
#' # ordered selection mechanism
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' rho <- 0.5
#' var.y <- 0.3
#' sd.y <- sqrt(var.y)
#' sigma <- matrix(c(1,          rho * sd.y,
#'                   rho * sd.y, var.y),
#'                 nrow = 2)
#' errors <- mnorm::rmnorm(n = n, mean = c(0, 0), sigma = sigma)
#' u <- errors[, 1]
#' eps <- errors[, 2]
#' 
#' # Coefficients
#' gamma <- c(-1, 2)
#' beta <- c(1, -1, 1)
#' 
#' # Linear index
#' li <- gamma[1] * w1 + gamma[2] * w2
#' li.y <- beta[1] + beta[2] * w1 + beta[3] * w3
#' 
#' # Latent variable
#' z_star <- li + u
#' y_star <- li.y + eps
#' 
#' # Cuts
#' cuts <- c(-1, 0.5, 2)
#' 
#' # Observable ordered outcome
#' z <- rep(0, n)
#' z[(z_star > cuts[1]) & (z_star <= cuts[2])] <- 1
#' z[(z_star > cuts[2]) & (z_star <= cuts[3])] <- 2
#' z[z_star > cuts[3]] <- 3
#' table(z)
#' 
#' # Observable continuous outcome such
#' # that outcome 'y' is observable only 
#' # when 'z > 1' and unobservable otherwise
#' # i.e. when 'z <= 1' we code 'y' as 'Inf'
#' y <- y_star
#' y[z <= 1] <- Inf
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, w3 = w3, 
#'                    z = z, y = y)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Estimation
#' model <- mvoprobit(list(z ~ w1 + w2),
#'                    list(y ~ w1 + w3),
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of ordered equation
#' cbind(true = gamma, estimate = model$coef[[1]])
#'   # cuts
#' cbind(true = cuts, estimate = model$cuts[[1]])   
#'   # regression coefficients of continuous equation
#' cbind(true = beta, estimate = as.numeric(model$coef2[[1]]))  
#'   # variance
#' cbind(true = var.y, estimate = as.numeric(model$var_y[[1]]))
#'   # covariance
#' cbind(true = rho * sd.y, estimate = as.numeric(model$cov_y[[1]]))
#' 
