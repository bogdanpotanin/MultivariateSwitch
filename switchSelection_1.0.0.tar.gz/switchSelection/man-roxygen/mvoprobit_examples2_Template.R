#' @examples
#' # -------------------------------
#' # Example 2
#' # Heteroscedastic ordered 
#' # probit model
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' 
#' # Random errors
#' u <- rnorm(n, mean = 0, sd = 1)
#' 
#' # Coefficients of mean equation
#' gamma <- c(-1, 2)
#' 
#' # Coefficients of variance equation
#' gamma_het <- c(0.5, -1)
#' 
#' # Linear index of mean equation
#' li <- gamma[1] * w1 + gamma[2] * w2
#' 
#' # Linear index of variance equation
#' li_het <- gamma_het[1] * w2 + gamma_het[2] * w3
#' 
#' # Heteroscedastic stdandard deviation
#' # i.e. value of variance equation
#' sd_het <- exp(li_het)
#' 
#' # Latent variable
#' z_star <- li + u * sd_het
#' 
#' # Cuts
#' cuts <- c(-1, 0.5, 2)
#' 
#' # Observable ordered outcome
#' z <- rep(0, n)
#' z[(z_star > cuts[1]) & (z_star <= cuts[2])] <- 1
#' z[(z_star > cuts[2]) & (z_star <= cuts[3])] <- 2
#' z[z_star > cuts[3]] <- 3
#' table(z)
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, w3 = w3, z = z)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Estimation
#' model <- mvoprobit(z ~ w1 + w2 | w2 + w3,
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of mean equation
#' cbind(true = gamma, estimate = model$coef[[1]])
#'   # regression coefficients of variance equation
#' cbind(true = gamma_het, estimate = model$coef_var[[1]])  
#'   # cuts
#' cbind(true = cuts, estimate = model$cuts[[1]])   
#' 
#' # ---
#' # Step 3
#' # Estimation of probabilities and marginal effects
#' # ---
#' 
#' # Predict probability of dependent variable
#' # equals to 2 for every observation in a sample.
#' # P(z = 2)
#' prob <- predict(model, group = 2, type = "prob")
#' head(prob)
#' 
#' # Calculate mean marginal effect of w2 on P(z = 1)
#' mean(predict(model, group = 1, type = "prob", me = "w2"))
#' 
#' # Calculate corresponding probability, linear
#' # index and heteroscedastic standard deviations for 
#' # manually provided observations.
#'   # new data
#' newdata <- data.frame(z = c(1, 1), 
#'                       w1 = c(0.5, 0.2), 
#'                       w2 = c(-0.3, 0.8),
#'                       w3 = c(0.6, 0.1))
#'   # probability P(z = 2)
#' predict(model, group = 2, type = "prob", newdata = newdata)
#'   # linear index
#' predict(model, type = "li", newdata = newdata)
#'   # standard deviation
#' predict(model, type = "sd", newdata = newdata)
#'   # marginal effect of w3 on P(Z = 3)
#' predict(model, group = 3, type = "prob", newdata = newdata, me = "w3")
#'   # marginal effect of w2 on the standard error
#' predict(model, group = 2, type = "sd", newdata = newdata, me = "w2")
#'   # discrete marginal effect i.e. P(Z = 2 | w1 = 0.5) - P(Z = 2 | w1 = 0.2)
#' predict(model, group = 2, type = "prob", newdata = newdata,
#'         me = "w2", eps = c(0.2, 0.5))
#' 
