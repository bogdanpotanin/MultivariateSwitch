#' @examples
#' # -------------------------------
#' # Example 3
#' # Bivariate ordered probit model
#' # with heteroscedastic second
#' # equation
#' # -------------------------------
#' 
#' # ---
#' # Step 1
#' # Simulation of data
#' # ---
#' 
#' # Set seed for reproducibility
#' set.seed(123)
#' 
#' # The number of observations
#' n <- 1000
#' 
#' # Regressors (covariates)
#' w1 <- runif(n = n, min = -1, max = 1)
#' w2 <- runif(n = n, min = -1, max = 1)
#' w3 <- runif(n = n, min = -1, max = 1)
#' w4 <- runif(n = n, min = -1, max = 1)
#' 
#' # Covariance matrix of random errors
#' rho <- 0.5
#' sigma <- matrix(c(1,   rho,
#'                   rho, 1), 
#'                 nrow = 2)
#' 
#' # Random errors
#' u <- mnorm::rmnorm(n = n, mean = c(0, 0), sigma = sigma)
#' 
#' # Coefficients
#' gamma1 <- c(-1, 2)
#' gamma2 <- c(1, 1.5)
#' 
#' # Coefficients of variance equation
#' gamma2_het <- c(0.5, -1)
#' 
#' # Linear indexes
#' li1 <- gamma1[1] * w1 + gamma1[2] * w2
#' li2 <- gamma2[1] * w2 + gamma2[2] * w3
#' 
#' # Linear index of variance equation
#' li2_het <- gamma2_het[1] * w2 + gamma2_het[2] * w4
#' 
#' # Heteroscedastic stdandard deviation
#' # i.e. value of variance equation
#' sd2_het <- exp(li2_het)
#' 
#' # Latent variables
#' z1_star <- li1 + u[, 1]
#' z2_star <- li2 + u[, 2] * sd2_het
#' 
#' # Cuts
#' cuts1 <- c(-1, 0.5, 2)
#' cuts2 <- c(-2, 0)
#' 
#' # Observable ordered outcome
#'   # first outcome
#' z1 <- rep(0, n)
#' z1[(z1_star > cuts1[1]) & (z1_star <= cuts1[2])] <- 1
#' z1[(z1_star > cuts1[2]) & (z1_star <= cuts1[3])] <- 2
#' z1[z1_star > cuts1[3]] <- 3
#'   # second outcome
#' z2 <- rep(0, n)
#' z2[(z2_star > cuts2[1]) & (z2_star <= cuts2[2])] <- 1
#' z2[z2_star > cuts2[2]] <- 2
#'   # distribution
#' table(z1, z2)
#' 
#' # Data
#' data <- data.frame(w1 = w1, w2 = w2, 
#'                    w3 = w3, w4 = w4,
#'                    z1 = z1, z2 = z2)
#' 
#' # ---
#' # Step 2
#' # Estimation of parameters
#' # ---
#' 
#' # Estimation
#' model <- mvoprobit(list(z1 ~ w1 + w2,
#'                         z2 ~ w2 + w3 | w2 + w4),
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of the first equation
#' cbind(true = gamma1, estimate = model$coef[[1]])
#'   # regression coefficients of the second equation
#' cbind(true = gamma2, estimate = model$coef[[2]])
#'   # cuts of the first equation
#' cbind(true = cuts1, estimate = model$cuts[[1]])   
#'   # cuts of the second equation
#' cbind(true = cuts2, estimate = model$cuts[[2]]) 
#'   # correlation coefficients
#' cbind(true = rho, estimate = model$sigma[1, 2])  
#'   # regression coefficients of variance equation
#' cbind(true = gamma2_het, estimate = model$coef_var[[2]])
#' 
#' # ---
#' # Step 3
#' # Estimation of probabilities and linear indexes
#' # ---
#' 
#' # Predict probability P(z1 = 2, z2 = 0)
#' prob <- predict(model, group = c(2, 0), type = "prob")
#' head(prob)
#' 
#' # Calculate mean marginal effect of w2 on:
#'   # P(z1 = 1)
#' mean(predict(model, group = c(1, -1), type = "prob", me = "w2"))
#'   # P(z1 = 1, z2 = 0)
#' mean(predict(model, group = c(1, 0), type = "prob", me = "w2"))
#' 
#' # Calculate corresponding probability and linear 
#' # index for manually provided observations.
#'   # new data
#' newdata <- data.frame(z1 = c(1, 1), 
#'                       z2 = c(1, 1),
#'                       w1 = c(0.5, 0.2), 
#'                       w2 = c(-0.3, 0.8),
#'                       w3 = c(0.6, 0.1),
#'                       w4 = c(0.3, -0.5))
#'   # probability P(z1 = 2, z2 = 0)
#' predict(model, group = c(2, 0), type = "prob", newdata = newdata)
#'   # linear index
#' predict(model, type = "li", newdata = newdata)  
#'   # marginal probability P(z2 = 1)
#' predict(model, group = c(-1, 1), type = "prob", newdata = newdata) 
#'   # marginal probability P(z1 = 3)
#' predict(model, group = c(3, -1), type = "prob", newdata = newdata)
#'   # conditional probability P(z1 = 2 | z2 = 0)
#' predict(model, group = c(2, 0), given_ind = 2,
#'         type = "prob", newdata = newdata) 
#'   # conditional probability P(z2 = 1 | z1 = 3)
#' predict(model, group = c(3, 1), given_ind = 1,
#'         type = "prob", newdata = newdata) 
#'   # marginal effect of w4 on P(Z2 = 2)
#' predict(model, group = c(-1, 2),
#'         type = "prob", newdata = newdata, me = "w4")   
#'   # marginal effect of w4 on P(z1 = 3, Z2 = 2)
#' predict(model, group = c(3, 2),
#'         type = "prob", newdata = newdata, me = "w4") 
#'   # marginal effect of w4 on P(z1 = 3 | z2 = 2)
#' predict(model, group = c(3, 2), given_ind = 2,
#'         type = "prob", newdata = newdata, me = "w4")         
#' 
#' # ---
#' # Step 4
#' # Replication under non-random sample selection
#' # ---
#' 
#' # Suppose that z2 is unobservable when z1 = 1 or z1 = 3
#' z2[(z1 == 1) | (z1 == 3)] <- -1
#' data$z2 <- z2
#' 
#' # Replicate estimation procedure
#' model <- mvoprobit(list(z1 ~ w1 + w2,
#'                         z2 ~ w2 + w3 | w2 + w4),
#'                    data = data)
#' summary(model)
#' 
#' # Compare estimates and true values of parameters
#'   # regression coefficients of the first equation
#' cbind(true = gamma1, estimate = model$coef[[1]])
#'   # regression coefficients of the second equation
#' cbind(true = gamma2, estimate = model$coef[[2]])
#'   # cuts of the first equation
#' cbind(true = cuts1, estimate = model$cuts[[1]])   
#'   # cuts of the second equation
#' cbind(true = cuts2, estimate = model$cuts[[2]]) 
#'   # correlation coefficients
#' cbind(true = rho, estimate = model$sigma[1, 2])  
#'   # regression coefficients of variance equation
#' cbind(true = gamma2_het, estimate = model$coef_var[[2]])
#' 
